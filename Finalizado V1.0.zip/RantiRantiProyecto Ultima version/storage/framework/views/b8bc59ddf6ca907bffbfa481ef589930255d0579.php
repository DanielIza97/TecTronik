<?php $__env->startSection('titulo'); ?>
<title>Insertar</title>
<?php $__env->stopSection(); ?>   
<?php $__env->startSection('contenido'); ?>
<h2>
    Editar Receta
</h2>
<form class="form-horizontal" method="post" action="<?php echo e(route('recetasprotegido.update',$receta->idreceta)); ?>" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <input type="hidden" name="_method" value="put">
  <div class="form-inline">
    <label for="id" class="col-sm-2 control-label">Id</label>
    <div>
      <input type="text" name="idreceta"value="<?php echo e($receta->idreceta); ?>"readonly >
    </div>
  </div>
  <div class="form-inline">
    <label for="nompro" class="col-sm-2 control-label">Tipo receta</label>
        <div>
        <select name="idtiporeceta">
          <?php $__currentLoopData = $caterece ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option label="<?php echo e($categoria->nombretiporeceta); ?>"><?php echo e($categoria->idtiporeceta); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br>
      </div>
    </div><br>
  <div class="form-inline">
    <label for="nomrece" class="col-sm-2 control-label" >Nombre de la receta</label>
    <div >
      <input type="Text" name="nombrereceta"value="<?php echo e($receta->nombrereceta); ?>">
    </div>
  </div>
  <div class="form-inline">
    <label for="nomcli" class="col-sm-2 control-label" >Descripcion</label>
    <div >
      <textarea name="descripcionreceta" rows="10" cols="50"> <?php echo e($receta->descripcionreceta); ?></textarea>
    </div>
  </div>
    <div class="form-inline">
      <label for="foto" class="col-sm-2 control-label">Fotrografia</label>
      <div class="form-inline">
        <img src="../imagesrecetas/<?php echo e($receta->imagenreceta); ?> "width="150"/>
        <input type="file" name="imagenreceta" accept="image/*">
      </div>
    </div>
    <div class="form-inline ">
      <div class="col-sm-offset-11 col-sm-10">
        <button type="submit" class="btn btn-success" >Actualizar</button>
      </div>
    </div>
  </form>
  <div style="padding-left:1%; padding-top:1%">
    <a href="/ingredientes/<?php echo e($receta->idreceta); ?>"class="btn btn-primary" >Agregar Ingredientes</a><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.PlantillaRecetas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documentos\GitHub\UnGrupoMas\RantiRantiProyecto - Segundo Avance\resources\views/CRUD/Recetasview/Editar.blade.php ENDPATH**/ ?>