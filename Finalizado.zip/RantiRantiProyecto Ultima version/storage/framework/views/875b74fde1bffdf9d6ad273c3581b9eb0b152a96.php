<?php $__env->startSection('content'); ?>
<div class="flex-center position-ref full-height">
    <section   >
        <div >
            <a href="<?php echo e('/admi/users'); ?>" class ="btn btn-add">Usuarios</a>
            <a href="<?php echo e('/productosprotegido'); ?>" class ="btn btn-add">Productos </a>
            <a href="<?php echo e('/recetasprotegido'); ?>" class ="btn btn-add">Recetas </a>
            <a href="<?php echo e('/categoriasP'); ?>" class ="btn btn-add">Categorias Productos </a>
            <a href="<?php echo e('/categoriasR'); ?>" class ="btn btn-add">Categorias Recetas </a>
            <a href="<?php echo e('/pedidos'); ?>" class ="btn btn-add">Ver pedidos</a>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documentos\GitHub\UnGrupoMas\RantiRantiProyecto Ultima version\resources\views/Indexmenu.blade.php ENDPATH**/ ?>