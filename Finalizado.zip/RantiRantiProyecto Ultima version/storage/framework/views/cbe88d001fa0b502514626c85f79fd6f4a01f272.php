<?php $__env->startSection('content'); ?>
<section>
    <ordendecompra-page>
    </ordendecompra-page>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documentos\GitHub\UnGrupoMas\RantiRantiProyecto Ultima version\resources\views/carrito.blade.php ENDPATH**/ ?>