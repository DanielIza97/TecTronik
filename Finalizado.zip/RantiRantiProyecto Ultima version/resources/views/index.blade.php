@extends('layouts.app')
@section('content')
<article>
    <categorias-slider></categorias-slider>
</article>
@endsection
