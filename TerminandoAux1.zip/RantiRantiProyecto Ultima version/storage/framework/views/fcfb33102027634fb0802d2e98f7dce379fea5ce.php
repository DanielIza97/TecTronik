<?php $__env->startSection('titulo'); ?>
<title>Insertar</title>
<?php $__env->stopSection(); ?>   
<?php $__env->startSection('contenido'); ?>
<h2>
    Editar Receta
</h2>
  <form class="form-horizontal" method="POST" action="<?php echo e(route('categoriasP.update',$categoriasp->idtipoprod)); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-inline">
      <label for="id" class="col-sm-2 control-label">Id Categoria</label>
      <div>
        <input type="text" name="idtipoprod" value="<?php echo e($categoriasp->idtipoprod); ?>">
      </div>
    </div>
    <div class="form-inline">
      <label for="nomrece" class="col-sm-2 control-label">Nombre de tipo de producto</label>
      <div >
        <input type="Text" name="nombretipoprod" value="<?php echo e($categoriasp->nombretipoprod); ?>">
      </div>
    </div>
    <div class="form-inline">
      <label for="foto" class="col-sm-2 control-label">Fotrografia</label>
      <div class="form-inline">
        <img src="../imagestipoprod/<?php echo e($categoriasp->fototipoprod); ?> "width="150"/>
        <input type="file" name="fototipoprod" accept="image/*">
      </div>
    </div>
    <div style="padding-left:1%; padding-top:1%">
        <button type="submit" class="btn btn-success" name="_method" value="PUT">Actualizar</button>
    </div>
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.PlantillaRecetas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Descargas\RantiRantiProyecto-Copi\resources\views/CRUD/CategoriaProductos/Editar.blade.php ENDPATH**/ ?>