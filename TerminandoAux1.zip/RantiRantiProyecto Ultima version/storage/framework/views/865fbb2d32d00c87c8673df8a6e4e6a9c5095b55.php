<?php $__env->startSection('titulo'); ?>
<title>Insertar</title>
<?php $__env->stopSection(); ?>   
<?php $__env->startSection('contenido'); ?>
<h2>
    Nueva Categoria
</h2>
  <form class="form-horizontal" method="POST" action="<?php echo e(route('categoriasP.store')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-inline">
      <label for="id" class="col-sm-2 control-label">Id Categoria</label>
      <div>
        <input type="text" name="idtipoprod">
      </div>
    </div>
    <div class="form-inline">
      <label for="nomrece" class="col-sm-2 control-label">Nombre de tipo de producto</label>
      <div >
        <input type="Text" name="nombretipoprod">
      </div>
    </div>
    <div class="form-inline">
      <label for="foto" class="col-sm-2 control-label">Fotrografia</label>
      <div class="form-inline">
        <input type="file" name="fototipoprod" accept="image/*">
      </div>
    </div>
    <div style="padding-left:1%; padding-top:1%">
        <button type="submit" class="btn btn-success">CREAR</button>
    </div>
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.PlantillaRecetas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documentos\GitHub\UnGrupoMas\RantiRantiProyecto - Segundo Avance\resources\views/CRUD/CategoriaProductos/Insertar.blade.php ENDPATH**/ ?>