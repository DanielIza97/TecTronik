<?php $__env->startSection('menu'); ?>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupported" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
    <span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarSupported">
    <div id="block-navegacionprincipal">
        
        <ul class="menu-menu">
            <li><p >Productos</p>
                <ul>
                    <?php $__currentLoopData = $categoriasp ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a class="dropdown-item"href="/productos/<?php echo e($cate->nombretipoprod); ?>"><?php echo e($cate->nombretipoprod); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
            <li><p>Recetas</p>
                <ul>
                    <?php $__currentLoopData = $categoriasr ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="/recetas/<?php echo e($cate->nombretiporeceta); ?>"><?php echo e($cate->nombretiporeceta); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<article>
    <div>
        <br><br> <h3 style="text-align: center">Productos</h3><br>
        <?php $__currentLoopData = $categoriasp ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <div class="row justify-content-center">
                <div class="card">
                    <div class="card-body"style="text-align: center">
                        <a href="/productos/<?php echo e($categoria->nombretipoprod); ?>"name="_method" value="put"> <img src="../imagestipoprod/<?php echo e($categoria->fototipoprod); ?>" width="100"/></a>
                    </div>
                    <div class="card-header"style="text-align: center">
                        <a  href="/productos/<?php echo e($categoria->nombretipoprod); ?>"name="_method" value="POST"><?php echo e($categoria->nombretipoprod); ?></a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <br><br> <h3 style="text-align: center">Recetas</h3><br>
        <?php $__currentLoopData = $categoriasr ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <div class="row justify-content-center">
                <div class="card">
                    <div class="card-body" style="text-align: center">
                        <a href="/recetas/<?php echo e($categoria->nombretiporeceta); ?>"> <img src="../imagestiporeceta/<?php echo e($categoria->fototiporece); ?>" width="100" /></a>
                    </div>
                    <div class="card-header"style="text-align: center;">
                        <a href="/recetas/<?php echo e($categoria->nombretiporeceta); ?>"><?php echo e($categoria->nombretiporeceta); ?></a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documentos\GitHub\UnGrupoMas\RantiRantiProyecto Ultima version Pruebas\resources\views/index.blade.php ENDPATH**/ ?>