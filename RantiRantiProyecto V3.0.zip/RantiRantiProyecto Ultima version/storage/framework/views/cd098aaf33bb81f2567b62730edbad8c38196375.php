<?php $__env->startSection('titulo'); ?>
<title>Insertar</title>
<?php $__env->stopSection(); ?>   
<?php $__env->startSection('contenido'); ?>
<h2>
    Editar producto
</h2>
<form class="form-horizontal" method="post" action="<?php echo e(route('productosprotegido.update',$producto->idproducto)); ?>" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <input type="hidden" name="_method" value="put">
  <div class="form-inline">
    <label for="Idproducto" class="col-sm-2 control-label">Id producto</label>
    <div>
      <input type="text" name="idproducto"value="<?php echo e($producto->idproducto); ?>" >
    </div>
  </div>
  <div class="form-inline">
    <label for="telfclien" class="col-sm-2 control-label">Nombre del producto</label>
    <div >
      <input type="Text" name="nombreproducto"value="<?php echo e($producto->nombreproducto); ?>">
    </div>
  </div>
  <div class="form-inline">
    <label for="telfclien" class="col-sm-2 control-label">Detalle</label>
    <div >
      <input type="Text" name="detalle"value="<?php echo e($producto->detalle); ?>">
    </div>
  </div>
  <div class="form-inline">
    <label for="idmedida" class="col-sm-2 control-label">Tipo de medida</label>
        <div>
        <select name="idmedida" >
            <option label="Unidades">M2</option>
            <option label="Libreado">M1</option>
        </select><br>
      </div>
    </div><br>
  <div class="form-inline">
    <label for="nompro" class="col-sm-2 control-label">Tipo producto</label>
        <div>
        <select name="idtipoprod">
          <?php $__currentLoopData = $cateprod ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option label="<?php echo e($categoria->nombretipoprod); ?>"><?php echo e($categoria->idtipoprod); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br>
      </div>
    </div><br>
  <div class="form-inline">
    <label for="tipprod" class="col-sm-2 control-label">Tamaño de producto</label>
    <div >
      <input type="Text" name="tamanoproducto" value="<?php echo e($producto->tamanoproducto); ?>">
    </div>
  </div>
  <div class="form-inline">
    <label for="cant" class="col-sm-2 control-label">Cantidad por cada tamaño</label>
    <div >
      <input type="Text" name="cantidadproducto"value="<?php echo e($producto->cantidadproducto); ?>">
    </div>
  </div>
  <div class="form-inline">
    <label for="pre" class="col-sm-2 control-label">Precio</label>
    <div >
      <input type="Text" name="precioproducto"value="<?php echo e($producto->precioproducto); ?>">
    </div>
  </div>
  <div class="form-inline">
    <label  for="imagenprod" class="col-sm-2 control-label">Fotografia</label>
    <div class="col-sm-offset-11 col-sm-10">
      <img src="../imagesproducto/<?php echo e($producto->imagenproducto); ?> "width="150"/>
      <input type="file" name="imagenproducto" accept="image/*">
    </div>
    </div>
        </div>
    <div class="form-inline ">
      <div class="col-sm-offset-11 col-sm-10">
        <button type="submit" class="btn btn-success" >Actualizar</button>
      </div>
    </div>
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.PlantillaProductos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documentos\GitHub\UnGrupoMas\RantiRantiProyecto - Segundo Avance\resources\views/CRUD/Productosview/Editar.blade.php ENDPATH**/ ?>