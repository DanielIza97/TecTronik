<?php $__env->startSection('content'); ?>
    <section>
        <h2>Ordenes pendientes</h2>
        <div class="row justify-content-center">
            <table class="table table-active">
                <thead>
                    <tr class="card-header">
                        <th><?php echo e(__('Id Pedido')); ?></th>
                        <th><?php echo e(__('Ver detalle pedido')); ?></th>
                        <th><?php echo e(__('Estado')); ?></th>
                    </tr>
                </thead>
                <tbody class="text-center">
                    <?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($pedido->idpedido); ?></td>
                            <td>
                                <a href="<?php echo e(url('pedidos/detalles/'.$pedido->idpedido)); ?>" class="btn btn-add">Detalle</a>
                                <form method="post" action="<?php echo e(url('pedidos/delete/'.$pedido->idpedido)); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button type="submit" ><i class="fa fa-trash btn btn-outline-danger"></i></button>
                                </form>
                            </td>
                            <td><?php echo e($pedido->estado); ?></td>
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </section>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documentos\GitHub\UnGrupoMas\RantiRantiProyecto Ultima version\resources\views/verordenes.blade.php ENDPATH**/ ?>