<?php $__env->startSection('titulo'); ?>
<title>Laravel</title>
<?php $__env->stopSection(); ?>   
<?php $__env->startSection('contenido'); ?>

<div class="col-sm-8">
    <h2>
        Listado de categorias de productos
        <a href="<?php echo e(route('categoriasP.create')); ?>"class="btn btn-primary pull-right">nuevo</a>
    </h2>
    <table class="table table-hover table-striped">
        <thead>
            <tr>
                <th with="20px">Codigo</th>
                <th> Nombre de categorias</th>
                <th> Foto tipo</th>
                <th colspan="2">&nbsp;</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $categoriasp ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoriap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($categoriap->idtipoprod); ?></td>
            <td><?php echo e($categoriap->nombretipoprod); ?></td>
            <td>
                <img src="../imagestipoprod/<?php echo e($categoriap->fototipoprod); ?>" width="75"/>
            </td>
            <td>
            <a href="<?php echo e(route('categoriasP.show',$categoriap->idtipoprod)); ?>"class="btn btn-primary" >Editar</a>
            </td>
            <td>
            <form action="<?php echo e(route('categoriasP.destroy',$categoriap->idtipoprod)); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="_method" value="DELETE">
                <button class="btn btn-link btn-warning" style="color: white">Eliminar</button>
            </form>
            </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.PlantillaGeneral', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documentos\GitHub\UnGrupoMas\RantiRantiProyecto - Segundo Avance\resources\views/CRUD/CategoriaProductos/Index.blade.php ENDPATH**/ ?>