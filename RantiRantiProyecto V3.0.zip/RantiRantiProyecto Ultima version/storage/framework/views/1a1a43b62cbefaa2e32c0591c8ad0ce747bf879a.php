<?php $__env->startSection('menu'); ?>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupported" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
    <span class="navbar-toggler-icon"></span>
</button>
<div  class="collapse navbar-collapse" id="navbarSupported">
    <div id="block-navegacionprincipal">
        
        <ul class="menu-menu dropdown-item1">
            <li><p >Productos</p>
                <ul>
                    <?php $__currentLoopData = $categoriasp ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="/productos/<?php echo e($cate->nombretipoprod); ?>"><?php echo e($cate->nombretipoprod); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
            <li><p>Recetas</p>
                <ul>
                    <?php $__currentLoopData = $categoriasr ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="/recetas/<?php echo e($cate->nombretiporeceta); ?>"><?php echo e($cate->nombretiporeceta); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if($categoria=='Productos'): ?>
<br><br> <h3 style="text-align: center">Productos</h3><br>
    <?php $__currentLoopData = $respuesta ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container">
            <div class="row justify-content-center">
                <div class="card">
                    <div class="card-body">
                        <a href="/productos/detalle/<?php echo e($prod->nombreproducto); ?>"> <img src="../imagesproducto/<?php echo e($prod->imagenproducto); ?>" width="100"/></a>
                    </div>
                    <div class="card-header">
                        <a href="/productos/detalle/<?php echo e($prod->nombreproducto); ?>"><?php echo e($prod->nombreproducto); ?></a>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<br><br> <h3 style="text-align: center"><?php echo e($categoria); ?></h3><br>
<?php $__currentLoopData = $respuesta ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="card">
            <div class="card-body"style="text-align: center">
                <a href="/recetas/detalle/<?php echo e($produ->nombrereceta); ?>"> <img src="../imagesrecetas/<?php echo e($produ->imagenreceta); ?>" width="100"/></a>
            </div>
            <div class="card-header"style="text-align: center">
                <a href="/recetas/detalle/<?php echo e($produ->nombrereceta); ?>"><?php echo e($produ->nombrereceta); ?></a>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
         
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documentos\GitHub\UnGrupoMas\RantiRantiProyecto Ultima version Pruebas\resources\views/unidad.blade.php ENDPATH**/ ?>