<?php $__env->startSection('titulo'); ?>
<title>Insertar</title>
<?php $__env->stopSection(); ?>   
<?php $__env->startSection('contenido'); ?>
<h2>
    Nueva Receta
</h2>
<form class="form-horizontal" method="POST" action="<?php echo e(route('recetas.store')); ?>"  enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
  <div class="form-inline">
    <label for="id" class="col-sm-2 control-label">Id</label>
    <div>
      <input type="text" name="idreceta">
    </div>
  </div>
  <div class="form-inline">
    <label for="nompro" class="col-sm-2 control-label">Tipo receta</label>
        <div>
        <select name="idtiporeceta">
          <?php $__currentLoopData = $caterece ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option label="<?php echo e($categoria->nombretiporeceta); ?>"><?php echo e($categoria->idtiporeceta); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br>
      </div>
    </div><br>
  <div class="form-inline">
    <label for="nomrece" class="col-sm-2 control-label">Nombre de la receta</label>
    <div >
      <input type="Text" name="nombrereceta">
    </div>
  </div>
  <div class="form-inline">
    <label for="des" class="col-sm-2 control-label">Descripcion</label>
    <div >
      <textarea name="descripcionreceta" rows="10" cols="50">
      </textarea>
    </div>
  </div>
    <div class="form-inline">
      <label for="imgrec" class="col-sm-2 control-label">Fotografia</label>
      <div >
        <input type="file" name="imagenreceta" accept="image/*">
        </div>
      </div>
      <div style="padding-left:1%; padding-top:1%">
          <button type="submit" class="btn btn-success">CREAR</button>
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.PlantillaRecetas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Descargas\RantiRantiProyecto-Copi\resources\views/CRUD/Recetasview/Insertar.blade.php ENDPATH**/ ?>