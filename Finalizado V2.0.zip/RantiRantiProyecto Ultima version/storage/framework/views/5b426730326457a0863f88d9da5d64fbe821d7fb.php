<?php $__env->startSection('content'); ?>
    <informacion-page :cedula="<?php echo e($cedula); ?>">
    </informacion-page>
<?php $__env->stopSection(); ?>
<script>
    src="<?php echo e(mix('js/app.js')); ?>"        
</script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documentos\GitHub\UnGrupoMas\RantiRantiProyecto Ultima version Pruebas\resources\views/informacion.blade.php ENDPATH**/ ?>