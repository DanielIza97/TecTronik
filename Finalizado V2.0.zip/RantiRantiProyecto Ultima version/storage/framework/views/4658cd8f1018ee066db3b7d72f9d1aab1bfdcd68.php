<?php $__env->startSection('content'); ?>
    <section>
        <div class="container">
            <div class="row justify-content-center m5">
                <div class=" col-lg-5 table-success">
                    <div class="card-header1 table-success"><span class="titulo">Codigo del pedido:</span> <?php echo e($pedido->idpedido); ?></div>
                    <div class="card-body1"><span class="titulo"> Nombre del Cliente:</span> <?php echo e($pedido->cliente->nombrecliente); ?></div>
                    <div class="card-body1"><span class="titulo"> Direccion:</span> <?php echo e($pedido->direcciones->calleprincipal); ?> <?php echo e($pedido->direcciones->numerodecasa); ?> y <?php echo e($pedido->direcciones->callesecundaria); ?> </div>
                    <div class="card-body1"><span class="titulo"> Fecha de pedido:</span>  <?php echo e($pedido->fechapedido); ?></div>
                    <div class="card-body1">
                        <form action="<?php echo e(url('pedidos/notificar/'.$pedido->idpedido)); ?>" method="POST" class="form-horizontal">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('PATCH')); ?>

                            <span class="titulo"> Estado de la entrega: </span>
                            <select name="estado" id="estado" class="select">
                                <option value="entregado" <?php echo e(("entregado" == $pedido->estado ? "selected":"")); ?>><?php echo e(__('entregado')); ?></option>
                                <option value="pendiente" <?php echo e((old("estado", "pendiente") == $pedido->estado ? "selected":"")); ?>><?php echo e(__('pendiente')); ?></option>
                                <option value="entregar" <?php echo e((old("estado", "entregar") == $pedido->estado ? "selected":"")); ?>><?php echo e(__('entregar')); ?></option>
                            </select>
                                <div class="card-body1 row justify-content-center">
                                    <input type="submit" class="btn btn-add" value="Entregar" <?php echo e(("entregado" == $pedido->estado ? "disabled":"")); ?>>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documentos\GitHub\UnGrupoMas\RantiRantiProyecto Ultima version\resources\views/ordendetalle.blade.php ENDPATH**/ ?>