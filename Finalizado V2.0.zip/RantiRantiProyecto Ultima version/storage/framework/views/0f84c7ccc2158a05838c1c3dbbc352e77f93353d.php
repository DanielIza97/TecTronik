<?php
?>
<?php $__env->startSection('content'); ?>
<section>
    <detalle-page  detallenombre="<?php echo e($request); ?>"tipo="<?php echo e($tipo); ?>">
    </detalle-page>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documentos\GitHub\UnGrupoMas\RantiRantiProyecto Ultima version\resources\views/detalles.blade.php ENDPATH**/ ?>