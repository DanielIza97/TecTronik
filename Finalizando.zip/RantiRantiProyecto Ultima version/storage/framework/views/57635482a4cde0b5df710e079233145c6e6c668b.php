<?php $__env->startSection('content'); ?>
<div >
    <div>
       <h4> Productos</h4>
        <?php $__currentLoopData = $categoriasp ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <a href="">&nbsp;&nbsp;&nbsp; <?php echo e($categoria->nombretipoprod); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <h4>Recetas</h4>
        <?php $__currentLoopData = $categoriasr ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <a href="">&nbsp;&nbsp;&nbsp; <?php echo e($categoria->nombretiporeceta); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div>
        <br><br> <h3 style="text-align: center">Productos</h3><br>
        <?php $__currentLoopData = $categoriasp ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container">
           <div class="row justify-content-center">
               <div class="col-md-8">
                   <div class="card">
                       <div class="card-body"style="text-align: center">
                           <a href="/productos/<?php echo e($categoria->nombretipoprod); ?>"name="_method" value="put"> <img src="../imagestipoprod/<?php echo e($categoria->fototipoprod); ?>" width="100"/></a>
                       </div>
                       <div class="card-header"style="text-align: center">
                           <a  href="/productos/<?php echo e($categoria->nombretipoprod); ?>"name="_method" value="POST"><?php echo e($categoria->nombretipoprod); ?></a>
                       </div>
                   </div>
               </div>
           </div>
       </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <br><br> <h3 style="text-align: center">Recetas</h3><br>
        <?php $__currentLoopData = $categoriasr ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container">
           <div class="row justify-content-center">
               <div class="col-md-8">
                   <div class="card">
                       <div class="card-body"style="text-align: center">
                           <a href="/recetas/<?php echo e($categoria->nombretiporeceta); ?>"> <img src="../imagestiporeceta/<?php echo e($categoria->fototiporece); ?>" width="100"/></a>
                       </div>
                       <div class="card-header"style="text-align: center">
                           <a href="/recetas/<?php echo e($categoria->nombretiporeceta); ?>"><?php echo e($categoria->nombretiporeceta); ?></a>
                       </div>
                   </div>
               </div>
           </div>
       </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documentos\GitHub\UnGrupoMas\RantiRantiProyecto-Copi\resources\views/index.blade.php ENDPATH**/ ?>