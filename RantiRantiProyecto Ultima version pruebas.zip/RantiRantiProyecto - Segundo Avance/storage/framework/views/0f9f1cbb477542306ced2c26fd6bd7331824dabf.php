<?php $__env->startSection('content'); ?>
<div class="flex-center position-ref full-height">
    <section   >
        <div >
            <a href="<?php echo e('/admi/users'); ?>" class ="btn btn-primary">Usuarios</a>
            <a href="<?php echo e('/productosprotegido'); ?>" class ="btn btn-primary">Productos </a>
            <a href="<?php echo e('/recetasprotegido'); ?>" class ="btn btn-primary">Recetas </a>
            <a href="<?php echo e('/categoriasP'); ?>" class ="btn btn-primary">Categorias Productos </a>
            <a href="<?php echo e('/categoriasR'); ?>" class ="btn btn-primary">Categorias Recetas </a>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documentos\GitHub\UnGrupoMas\RantiRantiProyecto-Copi\resources\views/Indexmenu.blade.php ENDPATH**/ ?>