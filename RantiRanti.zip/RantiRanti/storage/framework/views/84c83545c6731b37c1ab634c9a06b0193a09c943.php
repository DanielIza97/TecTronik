<?php $__env->startSection('titulo'); ?>
<title>Detalle</title>
<?php $__env->stopSection(); ?>   
<?php $__env->startSection('contenido'); ?>
  <div class="form-inline">
    <h3>Cedula:&nbsp;&nbsp;&nbsp;</h3>
  <h3 ><?php echo e($cliente->idcedulacliente); ?></h3>
  </div>
  <div class="form-inline">
    <h3>Nombre:&nbsp;&nbsp;&nbsp;</h3>
  <h3 ><?php echo e($cliente->nombrecliente); ?></h3>
  </div>
  <div class="form-inline">
    <h3>Telefono:&nbsp;&nbsp;&nbsp;</h3>
  <h3 ><?php echo e($cliente->telefonocliente); ?></h3>
  </div>
  <div class="form-inline">
  <img src="../images/<?php echo e($cliente->imagencliente); ?>"/>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layouts.Insertar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NTP\RantiRanti\resources\views/CRUD/Clientesview/Detalle.blade.php ENDPATH**/ ?>