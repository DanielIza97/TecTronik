<?php $__env->startSection('menu'); ?>
<div>
    <ul>
    <li> Productos</li>
    <?php $__currentLoopData = $categoriasp ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <ul>
    <li><a href="/productos/<?php echo e($cate->nombretipoprod); ?>"><?php echo e($cate->nombretipoprod); ?></a></li>
    </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <li>Recetas</li>
    <?php $__currentLoopData = $categoriasr ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <ul>
        <li><a href="/recetas/<?php echo e($cate->nombretiporeceta); ?>"><?php echo e($cate->nombretiporeceta); ?></a></li>
    </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if($categoria=='Productos'): ?>
<br><br> <h3 style="text-align: center">Productos</h3><br>
    <?php $__currentLoopData = $respuesta ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container">
            <div class="row justify-content-center">
                <div class="card">
                    <div class="card-body">
                        <a href="/productos/detalle/<?php echo e($prod->nombreproducto); ?>"> <img src="../imagesproducto/<?php echo e($prod->imagenproducto); ?>" width="100"/></a>
                    </div>
                    <div class="card-header">
                        <a href="/productos/detalle/<?php echo e($prod->nombreproducto); ?>"><?php echo e($prod->nombreproducto); ?></a>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<br><br> <h3 style="text-align: center"><?php echo e($categoria); ?></h3><br>
<?php $__currentLoopData = $respuesta ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="card">
            <div class="card-body"style="text-align: center">
                <a href="/recetas/detalle/<?php echo e($produ->nombrereceta); ?>"> <img src="../imagesrecetas/<?php echo e($produ->imagenreceta); ?>" width="100"/></a>
            </div>
            <div class="card-header"style="text-align: center">
                <a href="/recetas/detalle/<?php echo e($produ->nombrereceta); ?>"><?php echo e($produ->nombrereceta); ?></a>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
         
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documentos\GitHub\UnGrupoMas\RantiRantiProyecto - Segundo Avance\resources\views/unidad.blade.php ENDPATH**/ ?>