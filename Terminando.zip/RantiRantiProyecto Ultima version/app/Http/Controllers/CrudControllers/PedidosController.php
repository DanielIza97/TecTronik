<?php

namespace App\Http\Controllers\CrudControllers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PedidosController extends Controller
{
    //
}
