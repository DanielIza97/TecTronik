@extends('layouts.app')
@section('content')
<section>
    <ordendecompra-page>
    </ordendecompra-page>
</section>
@endsection