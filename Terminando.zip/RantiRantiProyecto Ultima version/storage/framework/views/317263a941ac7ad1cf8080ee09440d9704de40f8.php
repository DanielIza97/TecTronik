<?php $__env->startSection('titulo'); ?>
<title>Ranti</title>
<?php $__env->stopSection(); ?>   
<?php $__env->startSection('contenido'); ?>

<div class="col-sm-8">
    <h2>
        Listado de Usuarios
        <a href="<?php echo e(route('users.create')); ?>"class="btn btn-primary">nuevo</a>
    </h2>
    <?php if(session('mensaje')): ?>
        <div class="alert alert-success">
            <?php echo e(session('mensaje')); ?>

        </div>
    <?php endif; ?>
    <table class="table table-hover table-striped">
        <thead>
            <tr>
                <th with="20px">id</th>
                <th>Nombre </th>
                <th>Correo Electronico</th>
                <th>Rol</th>
                <th colspan="3">&nbsp;</th>
            </tr>
        </thead>
        <tbody>
                <?php $__currentLoopData = $users ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->rol); ?></td>
                    <?php if($user->rol=='cliente'): ?>
                    <td> 
                        <a href="/informacion_cliente/<?php echo e($user->id); ?>"class="btn btn-primary" >Informacion Cliente</a> 
                    </td>
                    <?php endif; ?>
                    <td>
                        <a href="<?php echo e(route('users.show',$user->id)); ?>"class="btn btn-primary" >Editar</a> 
                    </td>
                    <?php if($user->rol!='cliente'): ?>
                    <td>
                        <form action="<?php echo e(route('users.destroy',$user->id)); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="_method" value="DELETE">
                            <button class="btn btn-link btn-warning" style="color: white">Eliminar</button>
                        </form>
                    </td> 
                    <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.PlantillaGeneral', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documentos\GitHub\UnGrupoMas\RantiRantiProyecto Ultima version\resources\views/CRUD/Usersview/Index.blade.php ENDPATH**/ ?>