<?php $__env->startSection('content'); ?>
<?php if($categoria=='Productos'): ?>
<br><br> <h3 style="text-align: center">Productos</h3><br>
    <?php $__currentLoopData = $respuesta ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <a href=""><?php echo e($prod->nombreproducto); ?></a>
                        </div>
                        <div class="card-body">
                            <a href=""> <img src="../imagesproducto/<?php echo e($prod->imagenproducto); ?>" width="75"/></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<br><br> <h3 style="text-align: center">Recetas</h3><br>
    <?php $__currentLoopData = $respuesta ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <a href=""><?php echo e($respuesta->nombretiporeta); ?></a>
                        </div>
                        <div class="card-body">
                            <a href=""> <img src="../imagestiporeceta/<?php echo e($respuesta->fototiporece); ?>" width="75"/></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
         
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Descargas\RantiRantiProyecto-Copi\resources\views/unidad.blade.php ENDPATH**/ ?>