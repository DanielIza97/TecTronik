<?php $__env->startSection('titulo'); ?>
<title>Laravel</title>
<?php $__env->stopSection(); ?>   
<?php $__env->startSection('contenido'); ?>
<div class="col-sm-8">
    <table class="table table-hover table-striped">
        <thead>
            <tr>
                <th with="20px"> Id</th>
                <th> Calle Principal</th>
                <th > Calle Secundaria</th>
                <th > Numero de casa</th>
                <th > Foto</th>
                <th colspan="2">&nbsp;</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $direcciones ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $direccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($direccion->iddireccion); ?></td>
            <td><?php echo e($direccion->calleprincipal); ?></td>
            <td><?php echo e($direccion->callesecundaria); ?></td>
            <td><?php echo e($direccion->numerodecasa); ?></td>
            <td>
                <img src="../imagesdireccion/<?php echo e($direccion->imagendireccion); ?>" width="75"/>
            </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.PlantillaGeneral', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documentos\GitHub\UnGrupoMas\RantiRantiProyecto - Segundo Avance\resources\views/CRUD/Direccionesview/index.blade.php ENDPATH**/ ?>