<?php $__env->startSection('titulo'); ?>
<title>Insertar</title>
<?php $__env->stopSection(); ?>   
<?php $__env->startSection('contenido'); ?>
<h2>
    Editar Receta
</h2>
  <form class="form-horizontal" method="POST" action="<?php echo e(route('categoriasR.update',$categoriasr->idtiporeceta)); ?>">
    <?php echo csrf_field(); ?>
    <div class="form-inline">
      <label for="id" class="col-sm-2 control-label">Id Categoria</label>
      <div>
        <input type="text" name="idtiporeceta" value="<?php echo e($categoriasr->idtiporeceta); ?>">
      </div>
    </div>
    <div class="form-inline">
      <label for="nomrece" class="col-sm-2 control-label">Nombre de tipo de receta</label>
      <div >
        <input type="Text" name="nombretiporeceta" value="<?php echo e($categoriasr->nombretiporeceta); ?>">
      </div>
    </div>
    <div class="form-inline">
      <label for="foto" class="col-sm-2 control-label">Fotrografia</label>
      <div class="form-inline">
        <img src="../imagestiporeceta/<?php echo e($categoriasr->fototiporece); ?> "width="150"/>
        <input type="file" name="fototiporece" accept="image/*">
      </div>
    </div>
    <div style="padding-left:1%; padding-top:1%">
        <button type="submit" class="btn btn-success " name="_method" value="put">Actualizar</button>
    </div>
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.PlantillaRecetas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Descargas\RantiRantiProyecto-Copi\resources\views/CRUD/CategoriaRecetas/Editar.blade.php ENDPATH**/ ?>