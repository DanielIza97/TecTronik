<?php

?>
<?php $__env->startSection('menu'); ?>
<div>
    <ul>
    <li> Productos</li>
    <?php $__currentLoopData = $categoriasp ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <ul>
    <li><a href="/productos/<?php echo e($cate->nombretipoprod); ?>"><?php echo e($cate->nombretipoprod); ?></a></li>
    </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <li>Recetas</li>
    <?php $__currentLoopData = $categoriasr ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <ul>
        <li><a href="/recetas/<?php echo e($cate->nombretiporeceta); ?>"><?php echo e($cate->nombretiporeceta); ?></a></li>
    </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section>
    <div class="imagen_producto">
        <?php if($categoria=='producto'): ?>
            <figure >
                <img src="/imagesproducto/<?php echo e($producto[0]->imagenproducto); ?>" alt="Producto">
            </figure>
            <div class="descripción_producto">
                <h5 class="nombre_producto">Nombre del producto: <?php echo e($producto[0]->nombreproducto); ?></h5>
                <h5 class="nombre_producto">Detalle: <?php echo e($producto[0]->detalle); ?></h5>
                <h5 class="nombre_producto">Tamaño: <?php echo e($producto[0]->tamanoproducto); ?></h5>
                <h5 class="descripción_precio">$ Precio: <?php echo e($producto[0]->precioproducto); ?></h5>
                <input type="number" id="quantity" name="quantity" min="1" max="5">
                <input type="button" name="botón_agregar" value="Agregar al carrito">
            </div>
        <?php else: ?>
            <figure>
                <img src="/imagesrecetas/<?php echo e($receta[0]->imagenreceta); ?>" alt="Receta" width="300">
            </figure> 
            <div class="descripción_producto">
                <h4 class="nombre_producto">Nombre de la receta: <?php echo e($receta[0]->nombrereceta); ?></h4>
                <h4 class="nombre_producto">Procedimiento: <?php echo e($receta[0]->descripcionreceta); ?></h4>
                <h4 class="nombre_producto">Ingredientes:</h4>
                <?php $__currentLoopData = $ingredientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingrediente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h5><?php echo e($ingrediente->pivot->cantidad); ?> de <?php echo e($ingrediente->nombreproducto); ?>  </h5>
                    <input type="number" id="quantity" name="quantity" min="0.5" max="5" step="<?php echo e(0.5); ?>">
                    <input type="button" name="botón_agregar" value="Agregar al carrito">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>                
    </div>
    
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documentos\GitHub\UnGrupoMas\RantiRantiProyecto - Segundo Avance\resources\views/detalles.blade.php ENDPATH**/ ?>