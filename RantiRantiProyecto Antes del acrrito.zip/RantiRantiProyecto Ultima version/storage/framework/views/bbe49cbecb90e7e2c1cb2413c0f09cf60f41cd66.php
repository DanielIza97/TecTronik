<?php $__env->startSection('content'); ?>
<article>
<?php if($categoria=='Productos'): ?>
<div >
    <h3 class="container text-bg-left"><?php echo e($request); ?></h3><br>
    <div class="row justify-content-center">
        <?php $__currentLoopData = $respuesta ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <a href="/productos/detalle/<?php echo e($prod->nombreproducto); ?>">
                    <div class="card-body" style="background-image:url('../imagesproducto/<?php echo e($prod->imagenproducto); ?>')"></div>
                </a>
                <div class="card-header text-lg-center">
                    <a class="dropdown-item" href="/productos/detalle/<?php echo e($prod->nombreproducto); ?>"><?php echo e($prod->nombreproducto); ?></a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php else: ?>
<div>
    <h3 class="container text-bg-left"><?php echo e($request); ?></h3>
    <div>
        <div class="row justify-content-center">
            <?php $__currentLoopData = $respuesta ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <a href="/recetas/detalle/<?php echo e($produ->nombrereceta); ?>">
                    <div class="card-body text-lg-center"style="background-image:url('../imagesrecetas/<?php echo e($produ->imagenreceta); ?>')"></div>
                </a>
                <div class="card-header text-lg-center">
                    <a class="dropdown-item" href="/recetas/detalle/<?php echo e($produ->nombrereceta); ?>"><?php echo e($produ->nombrereceta); ?></a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php endif; ?> 
</article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documentos\GitHub\UnGrupoMas\RantiRantiProyecto Ultima version\resources\views/unidad.blade.php ENDPATH**/ ?>