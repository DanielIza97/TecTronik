<?php $__env->startSection('titulo'); ?>
<title>Insertar</title>
<?php $__env->stopSection(); ?>   
<?php $__env->startSection('contenido'); ?>
<h2>
    Editar Usuarios
</h2>
<form class="form-horizontal" method="post" action="<?php echo e(route('users.update',$users->id)); ?>" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <input type="hidden" name="_method" value="put">
  <div class="form-inline">
    <label for="Cedula" class="col-sm-2 control-label">Id</label>
    <div>
      <input type="text" name="id"value="<?php echo e($users->id); ?>" >
    </div>
  </div>
  <div class="form-inline">
    <label for="nomcli" class="col-sm-2 control-label" >Nombre Usuario</label>
    <div >
      <input type="Text" name="name"value="<?php echo e($users->name); ?>">
    </div>
  </div>
  <div class="form-inline">
    <label for="nomcli" class="col-sm-2 control-label" >Email</label>
    <div >
      <input type="Text" name="email"value="<?php echo e($users->email); ?>">
    </div>
  </div>
    <div class="form-inline">
      <label for="telfclien" class="col-sm-2 control-label">Rol</label>
      <div >
        <input type="Text" name="rol"value="<?php echo e($users->rol); ?>">
      </div>
    </div>
    <div class="form-inline">
      <label for="correo" class="col-sm-2 control-label" >Password</label>
      <div>
        <input type="Text" name="password" value="<?php echo e($users->password); ?>" readonly>
      </div>
    </div>
    <div class="form-inline">
      <label for="foto" class="col-sm-2 control-label">FOTO</label>
      <div class="form-inline">
        <img src="/imagesusers/<?php echo e($users->fotouser); ?>" width="75"/>
        <input type="file" name="fotouser" accept="image/*">
      </div>
    </div>
    <div class="form-inline ">
      <div class="col-sm-offset-11 col-sm-10">
        <button type="submit" class="btn btn-success" >Actualizar</button>
      </div>
    </div>
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.Plantillausers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documentos\GitHub\UnGrupoMas\RantiRantiProyecto - Segundo Avance\resources\views/CRUD/Usersview/Editar.blade.php ENDPATH**/ ?>