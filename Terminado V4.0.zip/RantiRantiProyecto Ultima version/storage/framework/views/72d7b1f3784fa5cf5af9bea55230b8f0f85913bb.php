<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('images/logo.png')); ?>" />
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/jquery-3.5.1.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/toastr.js')); ?>" defer></script>
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('../css/font-awesome-4.7.0/css/font-awesome.min.css')); ?>">
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/estilos.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/toastr.css')); ?>" rel="stylesheet">

</head>
<body>
    <div id="app">
        <header >
            <div class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
                <div class="container">
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        <img src="/images/logo.png" width="50px">
                        <?php echo e(config('app.name', 'Laravel')); ?>

                    </a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <!-- Left Side Of Navbar -->
                        <ul class="navbar-nav mr-auto">
                            
                        </ul>

                        <!-- Right Side Of Navbar -->
                        <?php if(!(Auth::user()==null)): ?>
                            <?php if(!(Auth::user()->rol=='administrador')): ?>
                                <carrito-navbar></carrito-navbar>
                            <?php endif; ?>  
                        <?php endif; ?> 
                        <ul class="navbar-nav ml-auto">
                            <!-- Authentication Links -->
                            <?php if(auth()->guard()->guest()): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('login')); ?>"><?php echo e(__('Iniciar sesion')); ?></a>
                                </li>
                                <?php if(Route::has('register')): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Crear Cuenta')); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php else: ?>
                            <div style="background-image:url('/imagesusers/<?php echo e(Auth::user()->fotouser); ?>')" class="image"></div>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle"  href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <div class="centrado"><?php echo e(Auth::user()->name); ?></div>  
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <?php if(Auth::user()->rol=='cliente'): ?>
                                        <a class="dropdown-item" href="/clienteinformacion/<?php echo e(Auth::user()->name); ?>">
                                            <?php echo e(__('Información')); ?>

                                        </a>
                                    <?php endif; ?>
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                                    document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Cerrar Sesión')); ?>

                                    </a>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">                                        
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
            <?php if(!(Auth::user()==null)): ?>
                <?php if(!(Auth::user()->rol=='administrador')): ?>
                    <nav class="navbar navbar-expand-md navbar-light bg-white1 shadow-sm">
                            <menu-navbar></menu-navbar>
                        </nav>
                <?php endif; ?>
            <?php else: ?>
                <nav class="navbar navbar-expand-md navbar-light bg-white1 shadow-sm">
                    <menu-navbar></menu-navbar>
                </nav>      
            <?php endif; ?> 
        </header>
        <main class="">
            <?php if(auth()->guard()->guest()): ?>
            <?php else: ?>    
                <notificacion-vue usuario="<?php echo e(Auth::user()->idcedulacliente); ?>"></notificacion-vue>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <footer class="card-footer">
            <div class="footer-content">
                <h1>
                    Ranti-Ranti
                </h1>
                <div class="footer-section contact icon">
                    <h4>Contactanos con:</h4>
                    <div>
                        <p>Teléfono:</p>
                        <div><i class="fa fa-phone" aria-hidden="true"></i>  Telf oficinas: 4751158</div>
                        <p>Tambien puedes escribirnos por nuestro correo electronico</p>
                        <div> <i class="fa fa-envelope-o" aria-hidden="true"></i> productosdecalid_rantiranti@gmail.com</div>
                    </div>
                </div>
                <div class="footer-section  links">
                    <h4>Puedes encontrarnos en:</h4>
                    <div>
                        <div class="icon">
                            <a href="https://www.facebook.com"><i class="fa fa-facebook " aria-hidden="true"></i>ranti-ranti_ec</a><br />
                            <a href="https://www.instagram.com/?hl=es-la"><i class="fa fa-instagram " aria-hidden="true"></i>@ranti-ranti_ec</a><br />
                            <a href="https://twitter.com/home"><i class="fa fa-twitter " aria-hidden="true"></i>#ranti-ranti_ec</a><br />
                        </div>
                    </div>
                </div>
            </div>
            <div id="container">
                <hr />
                <small> &#169 2020 Todos los derechos reservados. Diseñado por Grupo 10</small>
            </div>
        </footer>
    </div>
    <script>src="<?php echo e(mix('js/app.js')); ?>"  </script>
</body>
</html>
<?php /**PATH D:\Documentos\GitHub\UnGrupoMas\RantiRantiProyecto Ultima version\resources\views/layouts/app.blade.php ENDPATH**/ ?>