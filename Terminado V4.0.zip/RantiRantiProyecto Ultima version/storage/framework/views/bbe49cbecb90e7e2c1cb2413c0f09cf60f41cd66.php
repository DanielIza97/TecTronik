<?php $__env->startSection('content'); ?>
<article class="mt-4">
<?php if($categoria=='Productos'): ?>
<div >
    <h3 class="container text-bg-left"><?php echo e($request); ?></h3>
        <div class="offset-md-1 row justify-content-center m">
            <?php $__currentLoopData = $respuesta ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card1 ">
                    <a href="/productos/detalle/<?php echo e($prod->nombreproducto); ?>">
                    <img src="/imagesproducto/<?php echo e($prod->imagenproducto); ?>" class="card card-img-top align-self-center custom-control-inline" alt="'Sin foto'">
                    <div class="card-body1 dropdown-item mt-5"><?php echo e($prod->nombreproducto); ?></div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php else: ?>
<div>
    <h3 class="container text-bg-left"><?php echo e($request); ?></h3>
        <div class="offset-md-1 row justify-content-center m">
            <?php $__currentLoopData = $respuesta ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card1 ">
                    <a href="/recetas/detalle/<?php echo e($produ->nombrereceta); ?>">
                    <img src="/imagesrecetas/<?php echo e($produ->imagenreceta); ?>" class="card card-img-top align-self-center custom-control-inline" alt="'Sin foto'">
                    <div class="card-body1 dropdown-item mt-5"><?php echo e($produ->nombrereceta); ?></div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php endif; ?> 
</article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documentos\GitHub\UnGrupoMas\RantiRantiProyecto Ultima version\resources\views/unidad.blade.php ENDPATH**/ ?>